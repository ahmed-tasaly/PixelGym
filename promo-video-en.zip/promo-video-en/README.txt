https://lrusso.github.io/bannerGenerator/bannerVideo_01_Intro.htm         -    Image Size: 600     Image OffsetY: 80
https://lrusso.github.io/bannerGenerator/bannerVideo_02_Feature1.htm      -    Image Size: 420     Image OffsetY: 90
https://lrusso.github.io/bannerGenerator/bannerVideo_03_BothStores.htm    -    Image Size: 700     Image OffsetY: 150